# Cats Cards
This card mod will only add high quality cards with custom effects and or weapons/gimmicks.
Now featuring the TRT Lightsaber melee weapon.
this mod has been a WIP for close to if not even more than a year

feel free to give me feedback on the mod via the rounds modding server @CatsArmy
I'm unsure of how to balance the mod at the moment but still

## My Other Projects: 
If you have ever wanted more accurate stats? then here's CatInfo this mod is an add-on to 
[TabInfo](https://rounds.thunderstore.io/package/willreuploadscuzheruinedstuff/TabInfo/).
CatInfo adds lots of stats that are all toggleable.
Most stats are disabled by default 


## Special Thanks
>-  Thanks to [『 Root 』](https://rounds.thunderstore.io/package/Root/) for being a major part in creating the dev environment and more lil things
>-  Thanks to [willuwontu](https://rounds.thunderstore.io/package/willuwontu/ ) for helping create the lightsaber and for helping with handling bullets and boxes and animation
>-  [willuwontu](https://rounds.thunderstore.io/package/willreuploadscuzheruinedstuff/ ) ^^^ other profile
>-  Thanks to [Poppycars](https://thunderstore.io/c/rounds/p/poppycars/) for the card art and most importantly for the idea of creating this mod(also for the curse of the "TRT Lightsaber when?")
>- Lastly thanks to you the rounds community. without this community of devs and players i would never have discovered the fun in coding things