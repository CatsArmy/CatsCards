1.0.0: Initial release

1.0.2: A few backend changes and bug fixes